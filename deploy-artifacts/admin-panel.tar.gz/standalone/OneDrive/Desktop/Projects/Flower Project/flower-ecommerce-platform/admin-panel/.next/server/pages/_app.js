var R=require("../chunks/ssr/[turbopack]_runtime.js")("server/pages/_app.js")
R.c("server/chunks/ssr/[root-of-the-server]__b9ecfa3c._.js")
R.m(84925)
module.exports=R.m(84925).exports
