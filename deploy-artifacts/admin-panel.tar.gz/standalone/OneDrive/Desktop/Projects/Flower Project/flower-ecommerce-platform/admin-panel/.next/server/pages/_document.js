var R=require("../chunks/ssr/[turbopack]_runtime.js")("server/pages/_document.js")
R.c("server/chunks/ssr/[root-of-the-server]__f32fe14b._.js")
R.c("server/chunks/ssr/[root-of-the-server]__10000eb3._.js")
R.m(35481)
module.exports=R.m(35481).exports
