module.exports=[26157,a=>{a.v("/_next/static/media/favicon.0b3bf435.ico")},42428,a=>{"use strict";a.s(["default",()=>b]);let b={src:a.i(26157).default,width:256,height:256}}];

//# sourceMappingURL=b1735_Projects_Flower%20Project_flower-ecommerce-platform_admin-panel_src_app_7f261729._.js.map