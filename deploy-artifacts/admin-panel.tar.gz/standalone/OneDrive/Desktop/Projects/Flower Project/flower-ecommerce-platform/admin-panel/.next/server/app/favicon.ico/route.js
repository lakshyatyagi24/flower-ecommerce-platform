var R=require("../../chunks/[turbopack]_runtime.js")("server/app/favicon.ico/route.js")
R.c("server/chunks/[root-of-the-server]__735b2d53._.js")
R.c("server/chunks/f7148_next_dist_048b793a._.js")
R.c("server/chunks/[root-of-the-server]__52aa8be0._.js")
R.c("server/chunks/_7d66c1b0._.js")
R.m(76405)
R.m(35255)
module.exports=R.m(35255).exports
