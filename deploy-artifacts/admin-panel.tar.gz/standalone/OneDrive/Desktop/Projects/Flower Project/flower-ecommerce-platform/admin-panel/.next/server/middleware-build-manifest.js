globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": [
      "static/chunks/f556d5c7dd9127f6.js",
      "static/chunks/f5345b3110fa1668.js",
      "static/chunks/turbopack-8fae0b7280dbd09a.js"
    ],
    "/_error": [
      "static/chunks/c49923520f5d1b62.js",
      "static/chunks/f5345b3110fa1668.js",
      "static/chunks/turbopack-8ba4193f9c0c9c15.js"
    ]
  },
  "devFiles": [],
  "ampDevFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/2965402015ab589f.js",
    "static/chunks/88b189d863e48452.js",
    "static/chunks/77c343c0869e58bd.js",
    "static/chunks/f841fe3080ec77fc.js",
    "static/chunks/turbopack-3ad2aacec8dd95e6.js"
  ],
  "ampFirstPages": []
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
,"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js",

];