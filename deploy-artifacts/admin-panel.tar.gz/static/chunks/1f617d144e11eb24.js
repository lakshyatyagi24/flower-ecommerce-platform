__turbopack_load_page_chunks__("/_error", [
  "static/chunks/c49923520f5d1b62.js",
  "static/chunks/f5345b3110fa1668.js",
  "static/chunks/turbopack-8ba4193f9c0c9c15.js"
])
