__turbopack_load_page_chunks__("/_app", [
  "static/chunks/f556d5c7dd9127f6.js",
  "static/chunks/f5345b3110fa1668.js",
  "static/chunks/turbopack-8fae0b7280dbd09a.js"
])
